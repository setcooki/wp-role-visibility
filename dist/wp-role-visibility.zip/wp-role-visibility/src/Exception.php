<?php

namespace Setcooki\Wp\Role\Visibility;

/**
 * Class Exception
 * @package Setcooki\Wp\Role\Visibility
 */
class Exception extends \ErrorException
{
}