# wp-role-visibility

Make posts and page only visible for selected roles