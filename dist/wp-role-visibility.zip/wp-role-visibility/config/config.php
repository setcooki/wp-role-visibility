<?php

return
[
    'postTypes' => ['post', 'page']
];